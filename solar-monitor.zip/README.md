# ☀ Solar Monitor — Setup Guide
**Device:** aliyar · 48V · 6200W · Smart Solar

---

## ▶ OPTION 1 — Run in Termux (Local on Phone)

### One-Command Setup
```bash
# 1. Copy files to your phone, then in Termux:
cd solar-monitor
bash setup.sh
```

### Manual Setup
```bash
# Install Python in Termux
pkg install python -y

# Install libraries
pip install flask flask-cors requests anthropic

# Set your Anthropic API key (for AI suggestions)
export ANTHROPIC_API_KEY=sk-ant-xxxxxx

# Start the server
python app.py
```

### Access
Open your phone browser → `http://localhost:5000`

---

## 🌐 OPTION 2 — Public URL (Access from any device)

### Free tunnel via localhost.run (no install needed)
```bash
# Terminal 1 — run server
python app.py

# Terminal 2 — create public URL
ssh -R 80:localhost:5000 localhost.run
```
You'll get a URL like `https://abc123.localhost.run` — share it with anyone.

### Free tunnel via ngrok
```bash
pkg install wget -y
wget https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-arm64.tgz
tar xzf ngrok-*.tgz
./ngrok http 5000
```

---

## ☁ OPTION 3 — Free Cloud Hosting (Always Online)

### Render.com (Recommended — 100% free)
1. Create account → https://render.com
2. Push this folder to GitHub
3. New → Web Service → connect your repo
4. Set:
   - Build command: `pip install -r requirements.txt`
   - Start command: `gunicorn app:app`
   - Environment variable: `ANTHROPIC_API_KEY` = your key
5. Deploy → get permanent URL like `https://solar-monitor.onrender.com`

### Railway.app
1. https://railway.app → New Project → Deploy from GitHub
2. Add env var: `ANTHROPIC_API_KEY`
3. Done — auto-deploys on every push

### PythonAnywhere (Free always-on)
1. https://pythonanywhere.com → free account
2. Upload files → open Bash console:
   ```bash
   pip3 install flask flask-cors requests anthropic
   python app.py
   ```
3. Web tab → Add new web app → Flask → point to app.py

---

## 🤖 AI Suggestions Setup

Get a free Anthropic API key:
1. Go to https://console.anthropic.com
2. Sign up (free credits included)
3. API Keys → Create Key → copy `sk-ant-...`

Set it:
```bash
# Termux (permanent)
echo 'export ANTHROPIC_API_KEY=sk-ant-xxxx' >> ~/.bashrc
source ~/.bashrc

# Or just for this session
export ANTHROPIC_API_KEY=sk-ant-xxxx
```

---

## 📊 How to Use

1. Open `http://localhost:5000` in browser
2. Check your inverter display or Smart Solar app
3. Enter today's readings:
   - ☀️ Solar kWh generated
   - 🔋 Battery kWh used
   - ⚡ Utility/Grid kWh consumed
4. Press **SAVE READING**
5. Click **GET SUGGESTIONS** for AI timing advice
6. Check **TIMING GUIDE** tab for Pakistan-specific tips

---

## 🔧 Tips

- Log readings at the **same time each day** (e.g. 10pm)
- The donut chart shows your **energy mix** at a glance
- Red utility bar = too much grid dependency → get suggestions
- Export CSV weekly to track your progress
- AI suggestions improve as you add more data points
