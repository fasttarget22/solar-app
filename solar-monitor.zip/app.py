"""
Solar Monitor — Enhanced Dashboard for aliyar 48V 6200W Inverter
Run in Termux: python app.py
Free hosting: Render.com / Railway.app
"""
from flask import Flask, request, jsonify, render_template_string
import sqlite3, os, json, requests as req
from datetime import datetime, date

app  = Flask(__name__)
DB   = "solar.db"
DEVICE_URL  = "https://smartsolar.net.pk/D8BC38AD6637"
DEVICE_NAME = "aliyar"

# ─── DATABASE ────────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    c = get_db()
    c.execute("""
        CREATE TABLE IF NOT EXISTS readings (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            ts           TEXT    DEFAULT (datetime('now','localtime')),
            battery_kwh  REAL    DEFAULT 0,
            solar_kwh    REAL    DEFAULT 0,
            utility_kwh  REAL    DEFAULT 0,
            battery_pct  REAL    DEFAULT 0,
            load_w       REAL    DEFAULT 0,
            notes        TEXT    DEFAULT ''
        )
    """)
    c.commit(); c.close()

# ─── ROUTES ──────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template_string(HTML, device_url=DEVICE_URL, device_name=DEVICE_NAME)

@app.route("/api/log", methods=["POST"])
def log_reading():
    d = request.json or {}
    c = get_db()
    c.execute(
        "INSERT INTO readings (battery_kwh,solar_kwh,utility_kwh,battery_pct,load_w,notes) VALUES (?,?,?,?,?,?)",
        (d.get("battery_kwh", 0), d.get("solar_kwh", 0), d.get("utility_kwh", 0),
         d.get("battery_pct", 0), d.get("load_w", 0), d.get("notes", ""))
    )
    c.commit(); c.close()
    return jsonify({"ok": True, "message": "Reading saved ✓"})

@app.route("/api/history")
def history():
    c = get_db()
    rows = c.execute("SELECT * FROM readings ORDER BY id DESC LIMIT 60").fetchall()
    c.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/summary")
def summary():
    c = get_db()
    row = c.execute("""
        SELECT
            COALESCE(SUM(battery_kwh), 0)  AS total_battery,
            COALESCE(SUM(solar_kwh),   0)  AS total_solar,
            COALESCE(SUM(utility_kwh), 0)  AS total_utility,
            COALESCE(AVG(battery_pct), 0)  AS avg_battery_pct,
            COALESCE(MAX(load_w),      0)  AS peak_load,
            COUNT(*)                        AS record_count
        FROM readings
    """).fetchone()
    today = c.execute("""
        SELECT
            COALESCE(SUM(battery_kwh), 0) AS b,
            COALESCE(SUM(solar_kwh),   0) AS s,
            COALESCE(SUM(utility_kwh), 0) AS u
        FROM readings
        WHERE date(ts) = date('now','localtime')
    """).fetchone()
    c.close()
    return jsonify({**dict(row), "today": dict(today)})

@app.route("/api/suggest", methods=["POST"])
def suggest():
    d    = request.json or {}
    key  = os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        return jsonify({"suggestion":
            "⚠ Set ANTHROPIC_API_KEY environment variable to enable AI suggestions.\n\n"
            "In Termux:\n  export ANTHROPIC_API_KEY=sk-ant-xxxx\n  python app.py"})
    try:
        total = d.get("solar",0) + d.get("battery",0) + d.get("utility",0)
        solar_pct   = round(d.get("solar",0)   / total * 100, 1) if total else 0
        battery_pct = round(d.get("battery",0) / total * 100, 1) if total else 0
        utility_pct = round(d.get("utility",0) / total * 100, 1) if total else 0

        prompt = f"""You are a solar energy consultant helping a homeowner in Pakistan optimize their 48V 6200W solar inverter system.

Current energy data:
- ☀️  Solar generated : {d.get('solar', 0):.2f} kWh  ({solar_pct}% of total)
- 🔋 Battery used   : {d.get('battery', 0):.2f} kWh  ({battery_pct}% of total)
- ⚡ Utility/Grid   : {d.get('utility', 0):.2f} kWh  ({utility_pct}% of total)
- 🔋 Battery level  : {d.get('battery_level', 0):.0f}%
- 🏠 Peak load      : {d.get('peak_load', 0):.0f} W
- 📍 Location       : Pakistan (load shedding context)
- 🔧 Inverter       : 48V 6200W (6200VA)

Please provide:
1. **Usage Analysis** — what the numbers say about current habits
2. **Best timings** — what hours to run AC, washing machine, iron, water pump
3. **Inverter settings** — battery cutoff, grid charge timings, priority mode
4. **Load shedding strategy** — how to manage Pakistan's power cuts smartly
5. **Quick wins** — top 3 changes to reduce utility to below 20%

Be specific, practical, and concise. Use bullet points."""

        resp = req.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json"
            },
            json={
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 900,
                "messages": [{"role": "user", "content": prompt}]
            },
            timeout=30
        )
        result = resp.json()
        text   = result["content"][0]["text"]
        return jsonify({"suggestion": text})
    except Exception as e:
        return jsonify({"suggestion": f"API Error: {str(e)}"})

@app.route("/api/proxy")
def proxy():
    """Proxy the Smart Solar page to bypass CORS in frontend"""
    try:
        r = req.get(DEVICE_URL, timeout=10, headers={"User-Agent": "Mozilla/5.0"})
        return r.text, 200, {"Content-Type": "text/html; charset=utf-8"}
    except Exception as e:
        return f"<p>Failed to fetch live page: {e}</p>", 503

@app.route("/api/clear", methods=["POST"])
def clear():
    c = get_db()
    c.execute("DELETE FROM readings")
    c.commit(); c.close()
    return jsonify({"ok": True})

# ─── HTML TEMPLATE ────────────────────────────────────────────────────────────
HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title>Solar Monitor — {{ device_name }}</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<style>
@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=JetBrains+Mono:wght@300;400;600&display=swap');

*{box-sizing:border-box;margin:0;padding:0;}
:root{
  --bg:#07070f;--s:#0f0f1a;--card:#131320;--b:#1e1e30;
  --solar:#facc15;--battery:#4ade80;--utility:#f87171;--accent:#f59e0b;
  --t:#ddd8cc;--m:#6b6878;
}
body{background:var(--bg);color:var(--t);font-family:'JetBrains Mono',monospace;min-height:100vh;}
a{color:var(--accent);text-decoration:none;}

/* HEADER */
header{
  position:sticky;top:0;z-index:99;
  background:#0c0c18;border-bottom:1px solid var(--b);
  padding:0 20px;height:58px;
  display:flex;align-items:center;justify-content:space-between;
}
.logo{display:flex;align-items:center;gap:12px;}
.sun{
  width:36px;height:36px;border-radius:50%;
  background:radial-gradient(circle,#facc15 0%,#78450a 60%,transparent 100%);
  box-shadow:0 0 20px rgba(250,204,21,.4);
  display:flex;align-items:center;justify-content:center;font-size:18px;
}
.logo-text{font-family:Orbitron;font-weight:700;font-size:13px;color:var(--accent);letter-spacing:.18em;}
.logo-sub{font-size:9px;color:var(--m);letter-spacing:.1em;margin-top:2px;}
.status-pill{
  display:flex;align-items:center;gap:8px;
  padding:5px 14px;border-radius:20px;font-size:11px;font-weight:700;letter-spacing:.1em;
}
.dot{width:8px;height:8px;border-radius:50%;}
@keyframes gp{0%,100%{box-shadow:0 0 0 0 rgba(74,222,128,.4);}60%{box-shadow:0 0 0 8px rgba(74,222,128,0);}}
.dot.on{background:#4ade80;animation:gp 2s infinite;}
.dot.off{background:#f87171;}

/* MAIN */
main{padding:18px 18px;max-width:1300px;margin:0 auto;}

/* ENERGY CARDS */
.energy-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:18px;}
@media(max-width:650px){.energy-grid{grid-template-columns:1fr;}}
.ecard{
  background:var(--card);border:1px solid var(--b);border-radius:12px;
  padding:18px;position:relative;overflow:hidden;
}
.ecard::before{
  content:'';position:absolute;inset:0;opacity:.04;border-radius:12px;
}
.ecard.solar::before{background:var(--solar);}
.ecard.battery::before{background:var(--battery);}
.ecard.utility::before{background:var(--utility);}
.ecard-icon{font-size:28px;margin-bottom:10px;display:block;}
.ecard-label{font-size:9px;letter-spacing:.15em;color:var(--m);margin-bottom:6px;}
.ecard-val{font-family:Orbitron;font-size:26px;font-weight:700;}
.ecard.solar .ecard-val{color:var(--solar);}
.ecard.battery .ecard-val{color:var(--battery);}
.ecard.utility .ecard-val{color:var(--utility);}
.ecard-sub{font-size:10px;color:var(--m);margin-top:6px;}
.ecard-bar{height:4px;border-radius:2px;margin-top:12px;background:var(--b);}
.ecard-bar-fill{height:100%;border-radius:2px;transition:width .6s ease;}
.solar .ecard-bar-fill{background:var(--solar);}
.battery .ecard-bar-fill{background:var(--battery);}
.utility .ecard-bar-fill{background:var(--utility);}

/* LAYOUT */
.two-col{display:grid;grid-template-columns:1fr 360px;gap:14px;margin-bottom:14px;}
@media(max-width:900px){.two-col{grid-template-columns:1fr;}}
.card{background:var(--card);border:1px solid var(--b);border-radius:12px;padding:18px;}
.card-title{font-size:9px;color:var(--m);letter-spacing:.15em;margin-bottom:14px;text-transform:uppercase;}

/* CHART */
.chart-wrap{position:relative;height:240px;display:flex;align-items:center;justify-content:center;}
.chart-center{position:absolute;text-align:center;pointer-events:none;}
.chart-center-val{font-family:Orbitron;font-size:20px;font-weight:700;color:var(--accent);}
.chart-center-sub{font-size:9px;color:var(--m);letter-spacing:.1em;margin-top:3px;}

/* FORM */
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
@media(max-width:500px){.form-grid{grid-template-columns:1fr;}}
.field label{font-size:9px;color:var(--m);letter-spacing:.12em;display:block;margin-bottom:5px;}
.field input,.field textarea,.field select{
  background:var(--s);border:1px solid var(--b);color:var(--t);
  font-family:'JetBrains Mono',monospace;font-size:12px;
  border-radius:6px;padding:8px 10px;width:100%;outline:none;transition:border-color .2s;
}
.field input:focus,.field textarea:focus{border-color:var(--accent);}
.field-full{grid-column:1/-1;}

/* BUTTONS */
.btn{
  border:1px solid var(--b);color:var(--m);padding:8px 16px;
  cursor:pointer;font-family:'JetBrains Mono',monospace;font-size:11px;
  border-radius:7px;transition:all .18s;letter-spacing:.06em;background:transparent;
  display:inline-flex;align-items:center;gap:6px;
}
.btn:hover{border-color:var(--accent);color:var(--accent);}
.btn.primary{background:var(--accent);border-color:var(--accent);color:#000;font-weight:700;}
.btn.primary:hover{background:#d97706;}
.btn.green{background:#166534;border-color:#4ade80;color:#4ade80;}
.btn.red{background:#7f1d1d;border-color:#f87171;color:#f87171;}
.btn-row{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;}

/* TABLE */
table{width:100%;border-collapse:collapse;font-size:11px;}
th{text-align:left;padding:7px 8px;font-size:9px;color:var(--m);letter-spacing:.1em;border-bottom:1px solid var(--b);}
td{padding:7px 8px;border-bottom:1px solid #181828;}
tr:last-child td{border-bottom:none;}
tr:hover td{background:rgba(255,255,255,.02);}
.badge{display:inline-block;padding:2px 7px;border-radius:4px;font-size:9px;font-weight:700;}

/* AI SUGGESTIONS */
#ai-box{
  background:var(--s);border:1px solid rgba(245,158,11,.25);border-radius:8px;
  padding:14px;font-size:12px;line-height:1.75;color:var(--t);
  white-space:pre-wrap;min-height:80px;max-height:400px;overflow-y:auto;
}
#ai-box.loading{color:var(--m);font-style:italic;}

/* LIVE FRAME */
.live-wrap{background:var(--s);border:1px solid var(--b);border-radius:8px;overflow:hidden;}
.live-bar{
  padding:7px 14px;border-bottom:1px solid var(--b);font-size:10px;
  display:flex;align-items:center;justify-content:space-between;
}
iframe{width:100%;height:380px;border:none;display:block;}
.frame-note{padding:7px 14px;font-size:10px;color:var(--m);}

/* TABS */
.tabs{display:flex;margin-bottom:12px;}
.tab{
  background:transparent;border:1px solid var(--b);color:var(--m);
  padding:7px 14px;cursor:pointer;font-family:'JetBrains Mono',monospace;
  font-size:10px;letter-spacing:.1em;transition:all .18s;
}
.tab:first-child{border-radius:7px 0 0 7px;}
.tab:last-child{border-radius:0 7px 7px 0;}
.tab.on{background:var(--accent);border-color:var(--accent);color:#000;font-weight:700;}
.tab:hover:not(.on){border-color:var(--accent);color:var(--accent);}
.tab-panel{display:none;}.tab-panel.on{display:block;}

/* LEGEND */
.legend{display:flex;flex-direction:column;gap:10px;margin-top:16px;}
.legend-row{display:flex;align-items:center;justify-content:space-between;font-size:11px;}
.legend-dot{width:10px;height:10px;border-radius:50%;flex-shrink:0;}
.legend-label{display:flex;align-items:center;gap:8px;color:var(--m);}
.legend-val{font-weight:600;}

/* TOAST */
#toast{
  position:fixed;bottom:24px;right:24px;z-index:999;
  background:#1e2d1e;border:1px solid #4ade80;color:#4ade80;
  padding:10px 18px;border-radius:8px;font-size:12px;
  opacity:0;transition:opacity .3s;pointer-events:none;
}
#toast.show{opacity:1;}
</style>
</head>
<body>

<header>
  <div class="logo">
    <div class="sun">☀</div>
    <div>
      <div class="logo-text">SOLAR MONITOR</div>
      <div class="logo-sub">{{ device_name }} · 48V · 6200W · Enhanced Dashboard</div>
    </div>
  </div>
  <div id="status-pill" class="status-pill" style="border:1px solid #1e1e30">
    <div class="dot" id="status-dot"></div>
    <span id="status-text" style="color:var(--m)">CHECKING…</span>
  </div>
</header>

<main>

  <!-- ENERGY CARDS -->
  <div class="energy-grid">
    <div class="ecard solar">
      <span class="ecard-icon">☀️</span>
      <div class="ecard-label">SOLAR GENERATED (TOTAL)</div>
      <div class="ecard-val" id="solar-total">0.00 kWh</div>
      <div class="ecard-sub" id="solar-today">Today: 0.00 kWh</div>
      <div class="ecard-bar"><div class="ecard-bar-fill" id="solar-bar" style="width:0%"></div></div>
    </div>
    <div class="ecard battery">
      <span class="ecard-icon">🔋</span>
      <div class="ecard-label">BATTERY USED (TOTAL)</div>
      <div class="ecard-val" id="battery-total">0.00 kWh</div>
      <div class="ecard-sub" id="battery-today">Today: 0.00 kWh &nbsp;|&nbsp; Avg: 0%</div>
      <div class="ecard-bar"><div class="ecard-bar-fill" id="battery-bar" style="width:0%"></div></div>
    </div>
    <div class="ecard utility">
      <span class="ecard-icon">⚡</span>
      <div class="ecard-label">UTILITY / GRID USED (TOTAL)</div>
      <div class="ecard-val" id="utility-total">0.00 kWh</div>
      <div class="ecard-sub" id="utility-today">Today: 0.00 kWh</div>
      <div class="ecard-bar"><div class="ecard-bar-fill" id="utility-bar" style="width:0%"></div></div>
    </div>
  </div>

  <!-- CHART + FORM -->
  <div class="two-col">

    <!-- DONUT CHART -->
    <div class="card">
      <div class="card-title">Energy Source Distribution</div>
      <div class="chart-wrap">
        <canvas id="donut" style="max-width:240px;max-height:240px;"></canvas>
        <div class="chart-center">
          <div class="chart-center-val" id="chart-pct">—</div>
          <div class="chart-center-sub">SOLAR %</div>
        </div>
      </div>
      <div class="legend">
        <div class="legend-row">
          <div class="legend-label"><div class="legend-dot" style="background:var(--solar)"></div>Solar</div>
          <span class="legend-val" id="l-solar" style="color:var(--solar)">0%</span>
        </div>
        <div class="legend-row">
          <div class="legend-label"><div class="legend-dot" style="background:var(--battery)"></div>Battery</div>
          <span class="legend-val" id="l-battery" style="color:var(--battery)">0%</span>
        </div>
        <div class="legend-row">
          <div class="legend-label"><div class="legend-dot" style="background:var(--utility)"></div>Utility/Grid</div>
          <span class="legend-val" id="l-utility" style="color:var(--utility)">0%</span>
        </div>
      </div>
    </div>

    <!-- LOG READING FORM -->
    <div class="card">
      <div class="card-title">📥 Log New Reading</div>
      <div class="form-grid">
        <div class="field">
          <label>☀️ SOLAR kWh</label>
          <input type="number" id="f-solar" step="0.01" min="0" placeholder="e.g. 8.5">
        </div>
        <div class="field">
          <label>🔋 BATTERY kWh</label>
          <input type="number" id="f-battery" step="0.01" min="0" placeholder="e.g. 3.2">
        </div>
        <div class="field">
          <label>⚡ UTILITY kWh</label>
          <input type="number" id="f-utility" step="0.01" min="0" placeholder="e.g. 1.4">
        </div>
        <div class="field">
          <label>🔋 BATTERY %</label>
          <input type="number" id="f-bpct" step="1" min="0" max="100" placeholder="e.g. 75">
        </div>
        <div class="field">
          <label>🔌 CURRENT LOAD (W)</label>
          <input type="number" id="f-load" step="10" min="0" placeholder="e.g. 1200">
        </div>
        <div class="field">
          <label>📝 NOTES</label>
          <input type="text" id="f-notes" placeholder="Optional note…">
        </div>
      </div>
      <div class="btn-row">
        <button class="btn primary" onclick="logReading()">💾 SAVE READING</button>
        <button class="btn" onclick="clearForm()">✕ CLEAR</button>
      </div>
      <div style="margin-top:12px;font-size:10px;color:var(--m);line-height:1.7;">
        Read values from your <a href="{{ device_url }}" target="_blank">Smart Solar page ↗</a><br>
        or your inverter display / app.
      </div>
    </div>
  </div>

  <!-- AI SUGGESTIONS -->
  <div class="card" style="margin-bottom:14px;">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
      <div class="card-title" style="margin:0;">🤖 AI Suggestions — Reduce Utility Usage</div>
      <button class="btn primary" onclick="getSuggestions()">⚡ GET SUGGESTIONS</button>
    </div>
    <div id="ai-box" class="loading">
      Click "GET SUGGESTIONS" to analyze your energy data and get AI-powered recommendations
      on timing, inverter settings, and how to cut your utility/grid usage.
    </div>
  </div>

  <!-- TABS: HISTORY / LIVE VIEW -->
  <div class="card">
    <div class="tabs">
      <button class="tab on" onclick="showTab('history',this)">≡ READING HISTORY</button>
      <button class="tab" onclick="showTab('live',this)">▶ LIVE INVERTER VIEW</button>
      <button class="tab" onclick="showTab('tips',this)">💡 TIMING GUIDE</button>
    </div>

    <!-- HISTORY -->
    <div class="tab-panel on" id="tab-history">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
        <span style="font-size:10px;color:var(--m);" id="rec-count">0 records</span>
        <div style="display:flex;gap:8px;">
          <button class="btn" style="font-size:10px;padding:5px 10px;" onclick="exportCSV()">⬇ CSV</button>
          <button class="btn red" style="font-size:10px;padding:5px 10px;" onclick="clearAll()">🗑 CLEAR ALL</button>
        </div>
      </div>
      <div style="overflow-x:auto;">
        <table>
          <thead>
            <tr>
              <th>#</th><th>DATE / TIME</th>
              <th style="color:var(--solar)">☀ SOLAR kWh</th>
              <th style="color:var(--battery)">🔋 BATTERY kWh</th>
              <th style="color:var(--utility)">⚡ UTILITY kWh</th>
              <th>BATT %</th><th>LOAD W</th><th>NOTES</th>
            </tr>
          </thead>
          <tbody id="history-body">
            <tr><td colspan="8" style="text-align:center;color:var(--m);padding:24px;">No readings yet. Log your first reading above.</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- LIVE VIEW -->
    <div class="tab-panel" id="tab-live">
      <div class="live-wrap">
        <div class="live-bar">
          <span style="color:var(--solar);font-weight:700;font-size:10px;">● LIVE FEED</span>
          <a href="{{ device_url }}" target="_blank" style="font-size:10px;">⎋ Open full page</a>
        </div>
        <iframe src="{{ device_url }}" title="Smart Solar Live Status"></iframe>
        <div class="frame-note">ℹ If the frame is blank, the site blocks embedding. Use the link above.</div>
      </div>
    </div>

    <!-- TIMING TIPS -->
    <div class="tab-panel" id="tab-tips">
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px;">
        <div style="background:var(--s);border:1px solid var(--b);border-radius:8px;padding:14px;">
          <div style="color:var(--solar);font-size:13px;margin-bottom:8px;font-weight:700;">☀️ Peak Solar Hours</div>
          <div style="font-size:11px;color:var(--m);line-height:1.9;">
            <b style="color:var(--t)">09:00 – 16:00</b> — Best solar generation<br>
            Run AC, washing machine, iron in these hours<br>
            Avoid grid completely during this window<br>
            Charge battery to 100% before 15:00
          </div>
        </div>
        <div style="background:var(--s);border:1px solid var(--b);border-radius:8px;padding:14px;">
          <div style="color:var(--battery);font-size:13px;margin-bottom:8px;font-weight:700;">🔋 Battery Strategy</div>
          <div style="font-size:11px;color:var(--m);line-height:1.9;">
            <b style="color:var(--t)">Evening 17:00 – 23:00</b> — Run on battery<br>
            Set battery cutoff at 20% (48V → 46.5V)<br>
            Avoid heavy loads after 22:00<br>
            Priority: Solar → Battery → Grid
          </div>
        </div>
        <div style="background:var(--s);border:1px solid var(--b);border-radius:8px;padding:14px;">
          <div style="color:var(--utility);font-size:13px;margin-bottom:8px;font-weight:700;">⚡ Minimize Utility</div>
          <div style="font-size:11px;color:var(--m);line-height:1.9;">
            <b style="color:var(--t)">Grid allowed</b>: 02:00 – 06:00 only<br>
            Set inverter to charge battery from grid at off-peak<br>
            Disable grid-charge during daytime<br>
            Target: utility &lt; 15% of total
          </div>
        </div>
        <div style="background:var(--s);border:1px solid var(--b);border-radius:8px;padding:14px;">
          <div style="color:var(--accent);font-size:13px;margin-bottom:8px;font-weight:700;">🔧 Inverter Settings (48V)</div>
          <div style="font-size:11px;color:var(--m);line-height:1.9;">
            Output priority: <b style="color:var(--t)">Solar First (SBU)</b><br>
            Charger priority: <b style="color:var(--t)">Solar Only</b><br>
            Battery type: <b style="color:var(--t)">Li / AGM</b> (match yours)<br>
            Bulk charge: 56V · Float: 54V
          </div>
        </div>
      </div>
      <div style="margin-top:12px;padding:12px;background:rgba(245,158,11,.06);border:1px solid rgba(245,158,11,.2);border-radius:8px;font-size:11px;color:var(--m);line-height:1.8;">
        <b style="color:var(--accent);">Pakistan load shedding tip:</b>
        Know your schedule. If grid goes at 08:00 and returns at 12:00, 
        pre-charge your battery to 100% via grid before 07:45, 
        then switch inverter to Solar-only mode. 
        Use the AI Suggestions button above for personalized timing based on your actual usage data.
      </div>
    </div>
  </div>

</main>

<div id="toast">✓ Reading saved</div>

<script>
// ── State ──────────────────────────────────────────────────────────────────
let donutChart = null;
let historyData = [];

// ── Init ──────────────────────────────────────────────────────────────────
window.onload = () => {
  initDonut();
  loadSummary();
  loadHistory();
  checkStatus();
  setInterval(checkStatus, 30000);
};

// ── Status check ──────────────────────────────────────────────────────────
async function checkStatus() {
  const dot  = document.getElementById('status-dot');
  const text = document.getElementById('status-text');
  const pill = document.getElementById('status-pill');
  try {
    await fetch('{{ device_url }}', { mode:'no-cors', cache:'no-cache' });
    dot.className  = 'dot on';
    text.textContent = 'ONLINE';
    text.style.color = '#4ade80';
    pill.style.border = '1px solid #4ade8033';
    pill.style.background = 'rgba(74,222,128,.08)';
  } catch {
    dot.className  = 'dot off';
    text.textContent = 'OFFLINE';
    text.style.color = '#f87171';
    pill.style.border = '1px solid #f8717133';
    pill.style.background = 'rgba(248,113,113,.08)';
  }
}

// ── Donut chart ─────────────────────────────────────────────────────────
function initDonut() {
  const ctx = document.getElementById('donut').getContext('2d');
  donutChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Solar','Battery','Utility'],
      datasets: [{ data:[1,1,1], backgroundColor:['#facc15','#4ade80','#f87171'],
        borderWidth:2, borderColor:'#131320', hoverOffset:6 }]
    },
    options: {
      cutout:'72%', plugins:{legend:{display:false},tooltip:{enabled:true}},
      animation:{ animateRotate:true, duration:800 }
    }
  });
}

function updateDonut(solar, battery, utility) {
  const total = solar + battery + utility || 1;
  const sp = (solar/total*100).toFixed(1);
  const bp = (battery/total*100).toFixed(1);
  const up = (utility/total*100).toFixed(1);
  donutChart.data.datasets[0].data = [solar||0.001, battery||0.001, utility||0.001];
  donutChart.update();
  document.getElementById('chart-pct').textContent  = sp + '%';
  document.getElementById('l-solar').textContent    = sp + '%';
  document.getElementById('l-battery').textContent  = bp + '%';
  document.getElementById('l-utility').textContent  = up + '%';
  document.getElementById('solar-bar').style.width   = sp + '%';
  document.getElementById('battery-bar').style.width = bp + '%';
  document.getElementById('utility-bar').style.width = up + '%';
}

// ── Load summary ─────────────────────────────────────────────────────────
async function loadSummary() {
  try {
    const r = await fetch('/api/summary');
    const d = await r.json();
    document.getElementById('solar-total').textContent   = d.total_solar.toFixed(2) + ' kWh';
    document.getElementById('battery-total').textContent = d.total_battery.toFixed(2) + ' kWh';
    document.getElementById('utility-total').textContent = d.total_utility.toFixed(2) + ' kWh';
    document.getElementById('solar-today').textContent   = 'Today: ' + d.today.s.toFixed(2) + ' kWh';
    document.getElementById('battery-today').textContent =
      'Today: ' + d.today.b.toFixed(2) + ' kWh  |  Avg: ' + d.avg_battery_pct.toFixed(0) + '%';
    document.getElementById('utility-today').textContent = 'Today: ' + d.today.u.toFixed(2) + ' kWh';
    updateDonut(d.total_solar, d.total_battery, d.total_utility);
  } catch(e) { console.error('Summary error', e); }
}

// ── Load history ─────────────────────────────────────────────────────────
async function loadHistory() {
  try {
    const r = await fetch('/api/history');
    historyData = await r.json();
    document.getElementById('rec-count').textContent = historyData.length + ' records';
    const tbody = document.getElementById('history-body');
    if (!historyData.length) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--m);padding:24px;">No readings yet. Log your first reading above.</td></tr>';
      return;
    }
    tbody.innerHTML = historyData.map(row => {
      const ts = row.ts ? row.ts.replace('T',' ').slice(0,16) : '—';
      const util_cls = row.utility_kwh > row.solar_kwh ? 'color:var(--utility)' : '';
      return `<tr>
        <td style="color:var(--m)">${row.id}</td>
        <td style="color:var(--m);font-size:10px;">${ts}</td>
        <td style="color:var(--solar)">${(row.solar_kwh||0).toFixed(2)}</td>
        <td style="color:var(--battery)">${(row.battery_kwh||0).toFixed(2)}</td>
        <td style="${util_cls}">${(row.utility_kwh||0).toFixed(2)}</td>
        <td>${(row.battery_pct||0).toFixed(0)}%</td>
        <td>${(row.load_w||0).toFixed(0)}W</td>
        <td style="color:var(--m);font-size:10px;">${row.notes||'—'}</td>
      </tr>`;
    }).join('');
  } catch(e) { console.error('History error', e); }
}

// ── Log reading ─────────────────────────────────────────────────────────
async function logReading() {
  const body = {
    solar_kwh:   parseFloat(document.getElementById('f-solar').value)   || 0,
    battery_kwh: parseFloat(document.getElementById('f-battery').value) || 0,
    utility_kwh: parseFloat(document.getElementById('f-utility').value) || 0,
    battery_pct: parseFloat(document.getElementById('f-bpct').value)    || 0,
    load_w:      parseFloat(document.getElementById('f-load').value)    || 0,
    notes:       document.getElementById('f-notes').value.trim()
  };
  try {
    await fetch('/api/log', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body) });
    showToast('✓ Reading saved!');
    clearForm();
    loadSummary();
    loadHistory();
  } catch(e) { showToast('✗ Error saving'); }
}

function clearForm() {
  ['f-solar','f-battery','f-utility','f-bpct','f-load','f-notes'].forEach(id => {
    document.getElementById(id).value = '';
  });
}

// ── AI Suggestions ────────────────────────────────────────────────────────
async function getSuggestions() {
  const box = document.getElementById('ai-box');
  box.className = 'loading';
  box.textContent = '🤖 Analyzing your energy data… please wait (10-20 seconds)';

  const r = await fetch('/api/summary');
  const d = await r.json();
  const body = {
    solar:         d.total_solar,
    battery:       d.total_battery,
    utility:       d.total_utility,
    battery_level: d.avg_battery_pct,
    peak_load:     d.peak_load,
  };
  try {
    const resp = await fetch('/api/suggest', {
      method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)
    });
    const data = await resp.json();
    box.className = '';
    box.textContent = data.suggestion;
  } catch(e) {
    box.className = '';
    box.textContent = 'Error contacting AI. Check server logs.';
  }
}

// ── Tabs ──────────────────────────────────────────────────────────────────
function showTab(name, btn) {
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('on'));
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('on'));
  document.getElementById('tab-'+name).classList.add('on');
  btn.classList.add('on');
}

// ── Export CSV ────────────────────────────────────────────────────────────
function exportCSV() {
  const rows = [['ID','Timestamp','Solar kWh','Battery kWh','Utility kWh','Battery %','Load W','Notes']];
  historyData.forEach(r => rows.push([r.id,r.ts,r.solar_kwh,r.battery_kwh,r.utility_kwh,r.battery_pct,r.load_w,r.notes]));
  const csv  = rows.map(r => r.map(v => `"${v}"`).join(',')).join('\n');
  const a    = document.createElement('a');
  a.href     = URL.createObjectURL(new Blob([csv], {type:'text/csv'}));
  a.download = 'solar-readings.csv';
  a.click();
}

// ── Clear all ─────────────────────────────────────────────────────────────
async function clearAll() {
  if (!confirm('Delete ALL readings? This cannot be undone.')) return;
  await fetch('/api/clear', { method:'POST' });
  loadSummary(); loadHistory();
  showToast('🗑 All readings cleared');
}

// ── Toast ─────────────────────────────────────────────────────────────────
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2800);
}
</script>
</body>
</html>
"""

if __name__ == "__main__":
    init_db()
    port = int(os.environ.get("PORT", 5000))
    print(f"""
╔══════════════════════════════════════════════╗
║   ☀  Solar Monitor — aliyar 48V 6200W        ║
╠══════════════════════════════════════════════╣
║  Local:  http://localhost:{port}               ║
║  Network: http://0.0.0.0:{port}               ║
╚══════════════════════════════════════════════╝
Press CTRL+C to stop
    """)
    app.run(host="0.0.0.0", port=port, debug=False)
