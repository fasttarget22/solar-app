#!/data/data/com.termux/files/usr/bin/bash
# ══════════════════════════════════════════════════════
#   ☀  Solar Monitor — Termux Setup Script
#   Run: bash setup.sh
# ══════════════════════════════════════════════════════

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  ☀  Solar Monitor — Termux Installer     ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# 1. Update packages
echo "📦 Updating Termux packages..."
pkg update -y && pkg upgrade -y

# 2. Install Python
echo "🐍 Installing Python..."
pkg install python -y

# 3. Install pip dependencies
echo "📚 Installing Python libraries..."
pip install flask flask-cors requests anthropic gunicorn

# 4. Set API key
echo ""
echo "══════════════════════════════════════════"
echo "  ANTHROPIC API KEY (for AI Suggestions)"
echo "  Get free key: https://console.anthropic.com"
echo "  Press ENTER to skip for now"
echo "══════════════════════════════════════════"
read -p "  Paste API key (sk-ant-...): " APIKEY

if [ -n "$APIKEY" ]; then
  echo "export ANTHROPIC_API_KEY=$APIKEY" >> ~/.bashrc
  export ANTHROPIC_API_KEY=$APIKEY
  echo "✅ API key saved!"
else
  echo "⚠  Skipped — AI Suggestions will be disabled until you set it."
fi

echo ""
echo "══════════════════════════════════════════"
echo "  OPTIONAL: Public URL via localhost.run"
echo "  (Lets you access from any device)"
echo "══════════════════════════════════════════"
read -p "  Enable public tunnel? (y/n): " TUNNEL

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  ✅ Setup complete! Starting server...   ║"
echo "╚══════════════════════════════════════════╝"
echo ""

if [ "$TUNNEL" = "y" ] || [ "$TUNNEL" = "Y" ]; then
  pkg install openssh -y
  echo "🌐 Starting tunnel... (your public URL will appear below)"
  python app.py &
  sleep 2
  ssh -o StrictHostKeyChecking=no -R 80:localhost:5000 localhost.run
else
  echo "🚀 Dashboard: http://localhost:5000"
  echo "   Open in your phone browser"
  echo ""
  python app.py
fi
